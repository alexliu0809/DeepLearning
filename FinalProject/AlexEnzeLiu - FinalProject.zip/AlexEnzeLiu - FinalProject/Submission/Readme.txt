Final Project
Name: Alex Enze Liu
Data: 02/28/2017

How to run the code:
	To run stage1: python stage1.py
	To run stage2: python stage2.py (note that stage2 has an input file named "Stage1_Best
	.txt")

	The code of stage 2 only contains round 3.

Contact alexliu0809@uchicago.edu if you have any question regarding the code.